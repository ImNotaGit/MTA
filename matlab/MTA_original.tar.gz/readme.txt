1. get_binary_expH.m: take source state gene expressions, discretize into -1/0/1
2. taking the output from above, run iMAT, giving source state reaction fluxes
3. createDiscreteRxns_human.m: take source and target state gene expressions, give the directions of changes of reactions
4. taking the output from 2 and 3, run MTA
